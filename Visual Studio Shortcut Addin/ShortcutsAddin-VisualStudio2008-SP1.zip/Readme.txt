Visual Studio 2008 SP1 Installation instructions
-----------------------------------------------
(If anyone knows a way of making installers for Addins, please contact me)

1) Copy everything to your "C:\Users\<Username>\Documents\Visual Studio 2008\Addins directory"
2) Open Shortcuts.Addin in notepad
3) Change the <Assembly> tag to the location above
4) Run Visual Studio 2008
5) Go to Tools->Add-in Manager
6) Enable the Addin
8) The tool window should appear. Dock it if you like docking, or put it somewhere.
9) Use the right click menu to add your source files (only works in source view) to the list.
10) If you lose the window, it's available at the top of the View menu.

The favourites window may not display your favourites immediately. This is a minor bug in Vista (I think). Just close Visual Studio and re-open it, and your favourites will appear.

You can re-arrange the commands to your liking by customing the commands the same way you do with all menu items.

Your favourites are stored inside %appdata%\VS-ShortcutsAddin-Files.xml