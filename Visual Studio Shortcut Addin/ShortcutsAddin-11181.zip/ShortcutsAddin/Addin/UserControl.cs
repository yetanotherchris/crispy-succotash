using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Runtime.InteropServices;

namespace ShortcutsAddin
{
	/// <summary>
	/// The dockable toolwindow that holds the list of shortcuts.
	/// </summary>
	public class UserControl : System.Windows.Forms.UserControl
	{
		#region Control members
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ListView listViewMain;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.ContextMenu contextMenu;
		private System.Windows.Forms.MenuItem menuItemRemove;
		private System.Windows.Forms.ImageList imageListExtensions;
		#endregion

		#region Properties
		/// <summary>
		/// A way of accessing this instance back in the Connect class.
		/// As we don't actually create a new instance of UserControl in the Connect class
		/// (CreateToolWindow does it) we need a way of referencing this instance so we
		/// can right the list of shortcuts to disk when VS closes (OnDisconnect).
		/// </summary>
		public static UserControl Current
		{
			get
			{
				return _current;
			}
		}
		#endregion

		#region Private members
		/// <summary>
		/// The XML file to save the list of shortcut files to.
		/// </summary>
		private string XmlFilename
		{
			get
			{
				if ( string.IsNullOrEmpty( _xmlFilename ) )
				{
					//
					// Use the same filename for the lifetime of this VS. Stored in the roaming profile app data root.
					//
					_xmlFilename = System.Environment.GetFolderPath( System.Environment.SpecialFolder.ApplicationData );
					_xmlFilename += @"\VS-ShortcutsAddin-Files.xml";
				}

				return _xmlFilename;
			}
		}
		
		private string _xmlFilename;
		private static UserControl _current;
		private ArrayList _fileList = new ArrayList();
		private static readonly object lockObj = new Object();
		private Hashtable _extensionsTable = new Hashtable();
		#endregion

		#region Ctor, dispose
		public UserControl()
		{
			if ( _current == null )
			{
				lock ( lockObj )
				{
					_current = this;
				}
			}

			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// Load the list of shortcut files.
			this.LoadFromDisk();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}
			base.Dispose( disposing );
		}
		#endregion

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.listViewMain = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.contextMenu = new System.Windows.Forms.ContextMenu();
			this.menuItemRemove = new System.Windows.Forms.MenuItem();
			this.imageListExtensions = new System.Windows.Forms.ImageList(this.components);
			this.SuspendLayout();
			// 
			// listViewMain
			// 
			this.listViewMain.BackColor = System.Drawing.SystemColors.Control;
			this.listViewMain.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.listViewMain.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						   this.columnHeader1});
			this.listViewMain.ContextMenu = this.contextMenu;
			this.listViewMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listViewMain.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.listViewMain.FullRowSelect = true;
			this.listViewMain.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
			this.listViewMain.HideSelection = false;
			this.listViewMain.Location = new System.Drawing.Point(0, 0);
			this.listViewMain.Name = "listViewMain";
			this.listViewMain.Size = new System.Drawing.Size(312, 336);
			this.listViewMain.SmallImageList = this.imageListExtensions;
			this.listViewMain.TabIndex = 0;
			this.listViewMain.View = System.Windows.Forms.View.Details;
			this.listViewMain.DoubleClick += new System.EventHandler(this.listViewMain_DoubleClick);
			// 
			// columnHeader1
			// 
			this.columnHeader1.Width = 308;
			// 
			// contextMenu
			// 
			this.contextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						this.menuItemRemove});
			// 
			// menuItemRemove
			// 
			this.menuItemRemove.Index = 0;
			this.menuItemRemove.Text = "Remove";
			this.menuItemRemove.Click += new System.EventHandler(this.menuItemRemove_Click);
			// 
			// imageListExtensions
			// 
			this.imageListExtensions.ImageSize = new System.Drawing.Size(16, 16);
			this.imageListExtensions.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// UserControl
			// 
			this.Controls.Add(this.listViewMain);
			this.Name = "UserControl";
			this.Size = new System.Drawing.Size(312, 336);
			this.Resize += new System.EventHandler(this.UserControl_Resize);
			this.ResumeLayout(false);

		}
		#endregion

		#region Control events
		private void UserControl_Resize(object sender, System.EventArgs e)
		{
			this.listViewMain.Columns[0].Width = this.Width;
		}

		private void listViewMain_DoubleClick(object sender, System.EventArgs e)
		{
			//
			// Load the selected file
			//
			if ( this.listViewMain.SelectedItems.Count == 1 )
			{
				ListViewItem item = this.listViewMain.SelectedItems[0];
				FileInfo info = (FileInfo) item.Tag;

				// Open the file if it exists, otherwise just remove it from the listview.
				if ( File.Exists(info.FullName) )
				{
					EnvDTE.Window window = Connect.Current.DTEApplication.OpenFile(EnvDTE.Constants.vsViewKindTextView,info.FullName);
					window.Activate();
				}
				else
				{
					item.Remove();
				}
			}
		}

		private void menuItemRemove_Click(object sender, System.EventArgs e)
		{
			if ( this.listViewMain.SelectedItems.Count == 1 )
			{
				this.listViewMain.SelectedItems[0].Remove();
			}
		}
		#endregion

		#region Helper methods
		public void AddItem(string filename)
		{
			if ( !string.IsNullOrEmpty(filename) && File.Exists(filename) )
			{
				try
				{
					try
					{
						this.AddExtensionIcon( filename );

						FileInfo info = new FileInfo( filename );
						ListViewItem item = this.listViewMain.Items.Add( info.Name );
						item.Tag = info;

						if ( _extensionsTable.ContainsKey( info.Extension ) )
							item.ImageIndex = (int) _extensionsTable[info.Extension];
					}
					catch ( Exception )
					{
						MessageBox.Show( "[Shortcut Addin] An error occured while adding an item to the listview" );
					}
				}
				catch ( Exception )
				{
					MessageBox.Show( "[Shortcut Addin] An error occured while adding a shortcut. I'm not telling you anything more." );
				}
			}
		}

		/// <summary>
		/// Loads the list of shortcut files from the XML file. The XML file is very simple, 
		/// see below.
		/// </summary>
		/// <example>
		/// <code>
		/// <ShortcutFiles>
		/// <Filename Path="C:\Users\chris\Documents\Visual Studio 2005\WebSites\DynaScript\Default.aspx.cs" />
		/// <Filename Path="C:\Users\chris\Documents\Visual Studio 2005\WebSites\DynaScript\Web.Config" />
		/// </ShortcutFiles>
		/// </example>
		private void LoadFromDisk()
		{
			if ( File.Exists(this.XmlFilename) )
			{
				this._fileList = new ArrayList();

				// The filesize will always be small so XmlDocument is easier than
				// using XPath (until future versions, to prove I'm a Guru).
				XmlDocument doc = new XmlDocument();
				doc.Load(this.XmlFilename);

				if ( doc.ChildNodes.Count == 1 && doc.ChildNodes[0].ChildNodes.Count > 0 )
				{
					// Get all child nodes of /ShortCutFiles/*
					for (int i=0;i < doc.ChildNodes[0].ChildNodes.Count;i++)
					{
						XmlNode node = doc.ChildNodes[0].ChildNodes[i];

						if ( node.Attributes.Count == 1 )
						{
							string path = node.Attributes[0].Value;

							//
							// If the file exists and isn't in our list already, get it and add it
							// to the listview. Get its icon from the list or grab the icon.
							//
							if ( !string.IsNullOrEmpty(path) && File.Exists(path) && !this._fileList.Contains(path) )
							{
								try
								{
									FileInfo info = new FileInfo( path );
									ListViewItem item = this.listViewMain.Items.Add( info.Name );
									item.Tag = info;
									this._fileList.Add( path );

									this.AddExtensionIcon( path );

									if ( _extensionsTable.ContainsKey( info.Extension ) )
										item.ImageIndex = (int) _extensionsTable[info.Extension];
								}
								catch ( Exception )
								{
									MessageBox.Show( "[Shortcut Addin] An error occured while loading the shortcut list XML file" );
								}
							}
						
						}
					}
				}
			}
		}

		/// <summary>
		/// Saves the list of shortcuts to disk. This method is called from the Connect class.
		/// </summary>
		public void SaveToDisk()
		{
			try
			{
				XmlTextWriter writer = new XmlTextWriter( this.XmlFilename, System.Text.Encoding.ASCII );
				writer.Formatting = Formatting.Indented;
				writer.WriteStartElement( "ShortcutFiles" );

				for ( int i = 0 ; i < this.listViewMain.Items.Count ; i++ )
				{
					ListViewItem item = this.listViewMain.Items[i];

					if ( item.Tag is FileInfo )
					{
						FileInfo fileInfo = (FileInfo) item.Tag;

						writer.WriteStartElement( "Filename" );
						writer.WriteAttributeString( "Path", fileInfo.FullName );
						writer.WriteEndElement();
					}
				}

				writer.WriteEndElement();
				writer.Close();
			}
			catch ( Exception )
			{
				MessageBox.Show( "[Shortcut Addin] An error occured while writing the shortcut file list to disk" );
			}
		}

		private void AddExtensionIcon(string filename)
		{
			IntPtr hImgSmall;    //the handle to the system image list
			SHFILEINFO shinfo = new SHFILEINFO();

			FileInfo fileInfo = new FileInfo(filename);
			string extension = fileInfo.Extension;

			// See if we already have the extension icon
			if ( !_extensionsTable.ContainsKey(extension) )
			{
				// Create a temporary file to use with the win32 call
				//FileStream fileStream = File.Create(filename);
				//fileStream.Close();
					
				hImgSmall = Win32.SHGetFileInfo(filename, 0, ref shinfo,
					(uint)Marshal.SizeOf(shinfo),
					Win32.SHGFI_ICON |
					Win32.SHGFI_SMALLICON);

				// Add the icon if the call was successful
				if( hImgSmall.ToInt32() != 0 )
				{
					//The icon is returned in the hIcon member of the shinfo struct
					Icon icon = Icon.FromHandle(shinfo.hIcon);

					// Add it to the imagelist
					imageListExtensions.Images.Add(icon);	
						
					// Add it to our global extensions lookup
					_extensionsTable.Add(extension,imageListExtensions.Images.Count -1);
				}
			}
		}
		#endregion

		#region Win32 API (for icon lookups)
		[StructLayout(LayoutKind.Sequential)]
			public struct SHFILEINFO 
		{
			public IntPtr hIcon;
			public IntPtr iIcon;
			public uint dwAttributes;
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
			public string szDisplayName;
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
			public string szTypeName;
		}

		class Win32
		{
			public const uint SHGFI_ICON = 0x100;
			public const uint SHGFI_LARGEICON = 0x0;    // 'Large icon
			public const uint SHGFI_SMALLICON = 0x1;    // 'Small icon

			[DllImport("shell32.dll")]
			public static extern IntPtr SHGetFileInfo(string pszPath,
				uint dwFileAttributes,
				ref SHFILEINFO psfi,
				uint cbSizeFileInfo,
				uint uFlags);
		}
		#endregion
	}
}
