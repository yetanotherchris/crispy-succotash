Installation instructions
-----------------------------------------------
(An installer will be made soon).

1) Copy both .DLLs to your favourite directory
2) Open Shortcuts.Addin in notepad
3) Change the <Assembly> tag to the location you put the DLLs
4) Copy Shortcuts.Addin to your "...\Documents\Visual Studio 2005\Addins"
or "My Documents\Visual Studio 2005\Addins" wherever you have put it.
5) Run Visual Studio 2005
6) Go to Tools->Add-in Manager
7) Enable the Addin
8) The tool window should appear. Dock it if you like docking, or put it somewhere.
9) Use the right click menu to add your source files (only works in source view) to the list.
10) If you lose the window, it's availabe in the View menu.