using System;
using EnvDTE;
using Extensibility;
using System.Runtime.InteropServices;
using VSUserControlHostLib;
using Microsoft.Office.Core;
using System.Windows.Forms;

namespace ShortcutsAddin
{

	/// <summary>
	///   The object for implementing an Add-in.
	/// </summary>
	/// <seealso class='IDTExtensibility2' />
	[GuidAttribute("8FD0E084-B116-4A94-9E85-0BE6A3DC3181"), ProgId("ShortcutsAddin.Connect")]
	public class Connect : IDTExtensibility2, IDTCommandTarget
	{
		#region Properties
		/// <summary>
		/// Gets or the sets the ToolWindow
		/// </summary>
		public Window ToolWindow
		{
			get
			{
				return this._toolWindow;
			}
			set
			{
				if ( value != this._toolWindow )
					this._toolWindow = value;
			}
		}
		
		/// <summary>
		/// Gets or the sets the ContextMenuCommand
		/// </summary>
		public Command ContextMenuCommand
		{
			get
			{
				return this._contextMenuCommand;
			}
			set
			{
				if ( value != this._contextMenuCommand )
					this._contextMenuCommand = value;
			}
		}

		/// <summary>
		/// Gets or the sets the ViewMenuCommand
		/// </summary>
		public Command ViewMenuCommand
		{
			get
			{
				return this._viewMenuCommand;
			}
			set
			{
				if ( value != this._viewMenuCommand )
					this._viewMenuCommand = value;
			}
		}

		/// <summary>
		/// Gets or the sets the Current
		/// </summary>
		public static Connect Current
		{
			get
			{
				return _current;
			}
		}

		/// <summary>
		/// Gets or the sets the DTEApplication
		/// </summary>
		public _DTE DTEApplication
		{
			get
			{
				return this._dteApplication;
			}
			set
			{
				if ( value != this._dteApplication )
					this._dteApplication = value;
			}
		}
		#endregion

		#region Fields
		private _DTE _dteApplication;
		private AddIn _addInInstance;
		private Window _toolWindow;
		private VSUserControlHostLib.IVSUserControlHostCtl _objControl;
		private Command _viewMenuCommand;
		private Command _contextMenuCommand;
		private static Connect _current;
		#endregion

		#region Constructor
		public Connect()
		{
			// For use outside this class
			_current = this;
		}
		#endregion
		
		#region IDTExtensibility2 members
		/// <summary>
		///      Implements the OnConnection method of the IDTExtensibility2 interface.
		///      Receives notification that the Add-in is being loaded.
		/// </summary>
		/// <param term='application'>
		///      Root object of the host application.
		/// </param>
		/// <param term='connectMode'>
		///      Describes how the Add-in is being loaded.
		/// </param>
		/// <param term='addInInst'>
		///      Object representing this Add-in.
		/// </param>
		/// <seealso class='IDTExtensibility2' />
		public void OnConnection(object application, ext_ConnectMode connectMode, object addInInst, ref System.Array custom)
		{
			
			// This guid must be unique for each different tool window,
			// but you may use the same guid for the same tool window.
			// This guid can be used for indexing the windows collection,
			// for example: applicationObject.Windows.Item(guidstr)
			object objTemp = null;
			string toolWindowGuid = "{97601C90-678E-4a3f-92BA-A83C8DA5182E}";

			
			this.DTEApplication = (_DTE)application;
			this._addInInstance = (AddIn)addInInst;
			
			// Create the toolwindow (list of items)
			this.ToolWindow = this.DTEApplication.Windows.CreateToolWindow (this._addInInstance, "VSUserControlHost.VSUserControlHostCtl", "Shortcuts", toolWindowGuid, ref objTemp);

			// When using the hosting control, you must set visible to true before calling HostUserControl,
			// otherwise the UserControl cannot be hosted properly.
			this.ToolWindow.Visible = true;
			System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(@"C:\Documents and Settings\cs08\My Documents\Visual Studio Projects\ShortcutsAddin\Search16.bmp");
			
			// Set the tab icon
			//object pic = this.GetImage( bmp.GetHbitmap() );
			//this.ToolWindow.SetTabPicture( pic );

			this._objControl = (VSUserControlHostLib.IVSUserControlHostCtl)objTemp;
			System.Reflection.Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();
			this._objControl.HostUserControl(asm.Location, "ShortcutsAddin.UserControl");

			// Add menu items
			object[] o1 = new object[]{};
			object[] o2 = new object[]{};
			int options = (int)vsCommandStatus.vsCommandStatusSupported + (int) vsCommandStatus.vsCommandStatusEnabled;
			
			// Add an item to the view menu
			this.ViewMenuCommand = this.DTEApplication.Commands.AddNamedCommand(this._addInInstance, "ShortcutsAddinViewMenuItem","Shor&tcuts Window","Display the shortcuts window", true,1715,ref o1,options);
			
			// Have to access the View menu using the MenuBar
			CommandBar commandBar = (CommandBar) this.DTEApplication.CommandBars["MenuBar"];
			CommandBarControl viewControl = commandBar.Controls["View"];
			CommandBarPopup viewCmdBar = (CommandBarPopup)viewControl;
			CommandBarControl commandBarControl = this.ViewMenuCommand.AddControl(viewCmdBar.CommandBar,5);

			this.ContextMenuCommand = this.DTEApplication.Commands.AddNamedCommand(this._addInInstance, "ShortcutsAddinContextMenuItem","Add file as shortcut","Adds the file to your list of shortcuts",true,1715,ref o2,options);
			this.ContextMenuCommand.AddControl(this.DTEApplication.CommandBars["Code Window"],1);
		}


		/// <summary>
		///     Implements the OnDisconnection method of the IDTExtensibility2 interface.
		///     Receives notification that the Add-in is being unloaded.
		/// </summary>
		/// <param term='disconnectMode'>
		///      Describes how the Add-in is being unloaded.
		/// </param>
		/// <param term='custom'>
		///      Array of parameters that are host application specific.
		/// </param>
		/// <seealso class='IDTExtensibility2' />
		public void OnDisconnection(ext_DisconnectMode disconnectMode, ref System.Array custom)
		{
			if ( this._toolWindow != null )
				this._toolWindow.Visible = false;

			this.ContextMenuCommand.Delete();
			this.ViewMenuCommand.Delete();

			if ( UserControl.Current != null )
				UserControl.Current.SaveToDisk();
		}

		/// <summary>
		///      Implements the OnAddInsUpdate method of the IDTExtensibility2 interface.
		///      Receives notification that the collection of Add-ins has changed.
		/// </summary>
		/// <param term='custom'>
		///      Array of parameters that are host application specific.
		/// </param>
		/// <seealso class='IDTExtensibility2' />
		public void OnAddInsUpdate(ref System.Array custom)
		{
		}

		/// <summary>
		///      Implements the OnStartupComplete method of the IDTExtensibility2 interface.
		///      Receives notification that the host application has completed loading.
		/// </summary>
		/// <param term='custom'>
		///      Array of parameters that are host application specific.
		/// </param>
		/// <seealso class='IDTExtensibility2' />
		public void OnStartupComplete(ref System.Array custom)
		{
		}

		/// <summary>
		///      Implements the OnBeginShutdown method of the IDTExtensibility2 interface.
		///      Receives notification that the host application is being unloaded.
		/// </summary>
		/// <param term='custom'>
		///      Array of parameters that are host application specific.
		/// </param>
		/// <seealso class='IDTExtensibility2' />
		public void OnBeginShutdown(ref System.Array custom)
		{
		}
		#endregion

		#region IDTCommandTarget Members
		public void Exec(string CmdName, EnvDTE.vsCommandExecOption ExecuteOption, ref object VariantIn, ref object VariantOut, ref bool handled)
		{
			if ( CmdName == "ShortcutsAddin.Connect.ShortcutsAddinViewMenuItem" )
			{
				this.ToolWindow.Visible = true;
				this.ToolWindow.Activate();
				handled = true;
			}

			if ( CmdName == "ShortcutsAddin.Connect.ShortcutsAddinContextMenuItem" )
			{
				UserControl.Current.AddItem(this.DTEApplication.ActiveDocument.FullName);
			}
		}

		public void QueryStatus(string CmdName, EnvDTE.vsCommandStatusTextWanted NeededText, ref EnvDTE.vsCommandStatus StatusOption, ref object CommandText)
		{
			StatusOption = EnvDTE.vsCommandStatus.vsCommandStatusEnabled | EnvDTE.vsCommandStatus.vsCommandStatusSupported;
		}

		#endregion

		#region Tab icon OLE crap (bitmap to OLE picture type)
		[DllImport("olepro32.dll", PreserveSig=false)]
		internal static extern int OleCreatePictureIndirect(ref PICTDESC pPictDesc, ref System.Guid riid, bool fOwn, ref stdole.IPictureDisp ppvObj);

		internal struct PICTDESC
		{
			public int cbSizeOfStruct;
			public int picType;
			public IntPtr hPic;
			public IntPtr hpal;
			public int _pad;
		};


		public object GetImage(IntPtr hHandle)
		{

			PICTDESC pd = new PICTDESC();
			pd.cbSizeOfStruct = 144;//Marshal.SizeOf(pd);
			pd.hPic = hHandle;
			pd.hpal = new IntPtr(0);
			pd.picType = 1; // bitmap

			// Fill in magic IPicture GUID {7BF80980-BF32-101A-8BBB-00AA00300CAB}
			System.Guid iidIPicture = new Guid("7BF80980-BF32-101A-8BBB-00AA00300CAB");

			stdole.IPictureDisp ipic = null;
			int nResult = OleCreatePictureIndirect(ref pd, ref iidIPicture, true, ref ipic);

			return ipic;
		}
		#endregion
	}
}