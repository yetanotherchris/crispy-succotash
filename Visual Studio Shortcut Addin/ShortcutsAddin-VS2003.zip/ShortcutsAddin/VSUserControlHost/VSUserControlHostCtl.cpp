// VSUserControlHostCtl.cpp : Implementation of CVSUserControlHostCtl
#include "stdafx.h"
#include "VSUserControlHost.h"
#include "VSUserControlHostCtl.h"

//Import DTE:
//#import "libid:80cc9f66-e7d8-4ddd-85b6-d9e6cd0e93e2" version("7.0") lcid("0") raw_interfaces_only named_guids

#define IfFailGo(x) { hr=(x); if (FAILED(hr)) goto Error; }
#define IfFailGoCheck(x, p) { hr=(x); if (FAILED(hr)) goto Error; if(!p) {hr = E_FAIL; goto Error; } }

BOOL CVSUserControlHostCtl::PreTranslateAccelerator(LPMSG pMsg, HRESULT& hRet)
{
	hRet = S_OK;

	if ((pMsg->message < WM_KEYFIRST || pMsg->message > WM_KEYLAST) &&
		(pMsg->message < WM_MOUSEFIRST || pMsg->message > WM_MOUSELAST))
		return FALSE;
	// find a direct child of the dialog from the window that has focus
	HWND hWndCtl = ::GetFocus();
	if (IsChild(hWndCtl) && ::GetParent(hWndCtl) != m_hWnd)
	{
		do
		{
			hWndCtl = ::GetParent(hWndCtl);
		}
		while (::GetParent(hWndCtl) != m_hWnd);
	}
	// give controls a chance to translate this message
	if (::SendMessage(hWndCtl, WM_FORWARDMSG, 0, (LPARAM)pMsg) == 1)
		return TRUE;

	// special handling for keyboard messages
	LRESULT dwDlgCode = ::SendMessage(pMsg->hwnd, WM_GETDLGCODE, 0, 0);
	switch(pMsg->message)
	{
	case WM_CHAR:
		if(dwDlgCode == 0)	// no dlgcode, possibly an ActiveX control
			return FALSE;	// let the container process this
		break;
	case WM_KEYDOWN:
		switch(LOWORD(pMsg->wParam))
		{
		case VK_TAB:
		case VK_LEFT:
		case VK_UP:
		case VK_RIGHT:
		case VK_DOWN:
		case VK_RETURN:
			break;
		case VK_EXECUTE:
		case VK_ESCAPE:
		case VK_CANCEL:
			// we don't want to handle these, let the container do it
			return FALSE;
			// the container in this case is VS, we have some special keys which we also 
			// want the container to handle.  
			// (If you want to override the default VS behavior you can do it here.)
		case VK_F4:
		case VK_F5:
			// we don't want to handle these, let the container do it
			return FALSE;
		}
		break;
	}

	// specifically catch the case where its a CTRL or ALT combo'd command on WM_KEYDOWN
	// which is the message that VS needs passed to it to translate to a VS command, we
	// need to return false for those so they don't get eaten up by the calls to 
	// IsDialogMessage below
	if (pMsg->message == WM_KEYDOWN) 
	{
		if ((::GetKeyState(VK_CONTROL) < 0) || (::GetKeyState(VK_MENU) < 0))
			return FALSE;
	}

	BOOL bRet;
	//Process accel msg
	if ( (pMsg->message == WM_SYSCHAR) || (pMsg->message == WM_SYSKEYDOWN) || (pMsg->message == WM_SYSKEYUP) )
	{
		CONTROLINFO ci;
		HRESULT hr = GetControlInfo(&ci);
		if (SUCCEEDED(hr))
		{
			if (ci.cAccel > 0)
			{
				ACCEL* pAccel = new ACCEL[ci.cAccel];
				if (pAccel == NULL)
				{
					//Out of memory, don't send to control site
					hRet = E_OUTOFMEMORY;
					return TRUE;
				}
				int cAccel = CopyAcceleratorTable(ci.hAccel, pAccel, ci.cAccel);
				ATLASSERT(cAccel == ci.cAccel);
				bRet = FALSE;	//Accel not processed (invalid)
				WORD fVert = (pMsg->message == WM_SYSCHAR) ? FALT : 0;
				WORD key = LOWORD(pMsg->wParam);
				for (int i = 0; i < cAccel; i++)
				{
					if (((pAccel[i].fVirt & ~FNOINVERT & ~FVIRTKEY) == fVert) &&
						((pAccel[i].key == _toupper(key)) || pAccel[i].key == _tolower(key)))
					{
						bRet = ::IsDialogMessage(m_hWnd, pMsg);	//Accel is valid, process
						break;
					}
				}
				delete [] pAccel;
			}
			else
				bRet = FALSE;	//No accels to process, let the container handle
		}
		else
		{
			bRet = ::IsDialogMessage(m_hWnd, pMsg);	//Backward compt. (not impl GetControlInfo)
		}
	}
	else
	{
		bRet = ::IsDialogMessage(m_hWnd, pMsg);	//Not an accelerator msg
	}

	if (bRet)
	{
		HWND hWndCtlNewFocus = ::GetFocus();
		if (IsChild(hWndCtlNewFocus))
			m_hWndFocus = hWndCtlNewFocus;
		else
			m_hWndFocus = NULL;
		if (IsChild(hWndCtlNewFocus) && ::GetParent(hWndCtlNewFocus) != m_hWnd)
		{
			do
			{
				hWndCtlNewFocus = ::GetParent(hWndCtlNewFocus);
			}
			while (::GetParent(hWndCtlNewFocus) != m_hWnd);
		}

		if (IsChild(hWndCtlNewFocus)  && IsChild(hWndCtl) && hWndCtl != hWndCtlNewFocus)
		{
			CComPtr<IUnknown> spUnknown;
			HRESULT hr = AtlAxGetControl(hWndCtl, &spUnknown);
			if (SUCCEEDED(hr))
			{
				CComPtr<IOleInPlaceObject> spIOleInPlaceObject;
				hr = spUnknown->QueryInterface(&spIOleInPlaceObject);
				if (SUCCEEDED(hr))
					spIOleInPlaceObject->UIDeactivate();
			}
		}
	}
	return bRet;
}


LRESULT CVSUserControlHostCtl::OnSetFocus(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lParam, BOOL& bHandled)
{
	if(m_hWndForm)
	{
		::SetFocus((HWND)m_hWndForm);
		bHandled = TRUE;
		return 0;
	}
}

// CVSUserControlHostCtl
LRESULT CVSUserControlHostCtl::OnSize(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lParam, BOOL& bHandled)
{
	WORD wLength = LOWORD(lParam);
	WORD wHeight = HIWORD(lParam);
	::MoveWindow((HWND)m_hWndForm, 0, 0, wLength, wHeight, TRUE);
	bHandled = TRUE;
	return 0;
}

HRESULT CVSUserControlHostCtl::OnMnemonic(LPMSG pMsg)
{
	HRESULT hr = S_OK;
	if ((m_varUnwrappedObject.vt != VT_EMPTY) && (m_varUnwrappedObject.pdispVal))
	{
		CComPtr<IOleControl> pOLECtl;
		hr = m_varUnwrappedObject.pdispVal->QueryInterface(__uuidof(IOleControl), (LPVOID*)&pOLECtl);
		if((hr == S_OK) && (pOLECtl.p))
			hr = pOLECtl->OnMnemonic(pMsg);
	}
	return hr;
}

HRESULT CVSUserControlHostCtl::GetControlInfo(LPCONTROLINFO pCI)
{
	// forward to UserControl
	CComPtr<IOleControl> m_pIOleControl;
	if ((m_varUnwrappedObject.vt != VT_EMPTY) && (m_varUnwrappedObject.pdispVal))
	{
		HRESULT hr = m_varUnwrappedObject.pdispVal->QueryInterface(IID_IOleControl, (LPVOID*)&m_pIOleControl);
		if (FAILED(hr))
			return E_NOTIMPL;

		return m_pIOleControl->GetControlInfo(pCI);
	}
	return E_FAIL;
}

HRESULT CVSUserControlHostCtl::TranslateAccelerator(LPMSG pMsg)
{
	HRESULT hr = S_OK;

	if ((m_varUnwrappedObject.vt != VT_EMPTY) && (m_varUnwrappedObject.pdispVal))
	{
		CComPtr<IOleInPlaceActiveObject> pIPAO;
		hr = m_varUnwrappedObject.pdispVal->QueryInterface(__uuidof(IOleInPlaceActiveObject), (LPVOID*)&pIPAO);
		if((hr == S_OK) && (pIPAO.p))
		{
			hr = pIPAO->TranslateAccelerator(pMsg);
			if (hr == S_OK) return hr;
		}
	}

	return IOleInPlaceActiveObjectImpl<CVSUserControlHostCtl>::TranslateAccelerator(pMsg);
}

LRESULT CVSUserControlHostCtl::OnShow(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	HRESULT hr = 0;
	if (wParam == TRUE)
	{
		m_fVisible = TRUE;

		if (m_fNeedToLoad)
		{
			// window being shown
			if (m_varUnwrappedObject.vt != VT_EMPTY)
			{
				CComPtr<IWin32Window> pIWin32Window;

				hr = m_varUnwrappedObject.pdispVal->QueryInterface(__uuidof(IWin32Window), (LPVOID*)&pIWin32Window);
				if(FAILED(hr))
				{
					Reset();
					return hr;
				}
				hr = pIWin32Window->get_Handle(&m_hWndForm);
				if(FAILED(hr))
				{
					Reset();
					return hr;
				}
			}

			if (m_hWndForm)
			{
				ActivateWindow();
				m_fNeedToLoad = FALSE;
			}
		}
	}
	return hr;
}

void CVSUserControlHostCtl::ActivateWindow()
{
	if(m_hWndForm)
	{
		RECT rc;
		::SetParent((HWND)m_hWndForm, m_hWnd);
		::GetWindowRect(m_hWnd, &rc);
		::MoveWindow((HWND)m_hWndForm, 0, 0, rc.right-rc.left, rc.bottom-rc.top, TRUE);
		::ShowWindow((HWND)m_hWndForm, SW_SHOW);
		HWND hFirstTabItem = ::GetNextDlgTabItem((HWND)m_hWndForm, NULL, FALSE);
#ifdef _DEBUG
		WCHAR szTemp[100];
		::GetWindowTextW(hFirstTabItem, szTemp, 100);
#endif
		::SetFocus(hFirstTabItem);
	}
}

void CVSUserControlHostCtl::Reset()
{
	m_pHost = NULL;
	m_pDefaultDomain = NULL;
	m_pObjHandle = NULL;
	m_varUnwrappedObject.Clear();
	m_hWndForm = 0;
}

HRESULT CVSUserControlHostCtl::HostUserControl(BSTR Assembly, BSTR Class, IDispatch **ppControlObject)
{
	CComPtr<IWin32Window> pIWin32Window;
	HRESULT hr = m_pDefaultDomain->CreateInstance(Assembly, Class, &m_pObjHandle);
	if(FAILED(hr) || (!m_pObjHandle))
	{
		hr = m_pDefaultDomain->CreateInstanceFrom(Assembly, Class, &m_pObjHandle); 
		if(FAILED(hr) || (!m_pObjHandle))
		{
			hr = E_FAIL;
			Reset();
			return hr;
		}
	}
	hr = m_pObjHandle->Unwrap(&m_varUnwrappedObject);
	if((m_varUnwrappedObject.vt != VT_DISPATCH) && (m_varUnwrappedObject.vt != VT_UNKNOWN) || (!m_varUnwrappedObject.punkVal))
	{
		hr = E_FAIL;
		Reset();
		return hr;
	}

	hr = m_varUnwrappedObject.pdispVal->QueryInterface(IID_IDispatch, (LPVOID*)ppControlObject);
	hr = m_varUnwrappedObject.pdispVal->QueryInterface(__uuidof(IWin32Window), (LPVOID*)&pIWin32Window);
	if(FAILED(hr))
	{
		Reset();
		return hr;
	}
	hr = pIWin32Window->get_Handle(&m_hWndForm);
	if(FAILED(hr))
	{
		Reset();
		return hr;
	}
	if (m_hWndForm && m_fVisible) 
	{
		ActivateWindow();
		m_fNeedToLoad = FALSE; 
	}
	else
	{
		m_fNeedToLoad = TRUE; 
	}
	return hr;
}

HRESULT CVSUserControlHostCtl::HostUserControl2(OLE_HANDLE HWnd)
{
	m_hWndForm = (long)HWnd;

	if (m_hWndForm && m_fVisible)
	{
		ActivateWindow();
		m_fNeedToLoad = FALSE; 
	}
	else
	{
		// not ready to display control yet, wait for WM_SHOW
		m_fNeedToLoad = TRUE; 
	}

	return S_OK;
}

HRESULT CVSUserControlHostCtl::get_Object(IUnknown **pObject)
{
	if((m_varUnwrappedObject.punkVal) && ((m_varUnwrappedObject.vt == VT_UNKNOWN) || (m_varUnwrappedObject.vt == VT_DISPATCH)))
	{
		return m_varUnwrappedObject.pdispVal->QueryInterface(IID_IUnknown, (LPVOID*)pObject);
	}
	return E_FAIL;
}

HRESULT CVSUserControlHostCtl::FinalConstruct()
{
	CComPtr<IUnknown> pAppDomainPunk;
	HRESULT hr = S_OK;
	Reset();

	//IfFailGoCheck(CoCreateInstance(CLSID_CorRuntimeHost, NULL, CLSCTX_INPROC_SERVER, IID_ICorRuntimeHost, (void**)&m_pHost), m_pHost);
	IfFailGoCheck(CorBindToRuntimeEx(NULL, NULL, STARTUP_LOADER_OPTIMIZATION_SINGLE_DOMAIN | STARTUP_CONCURRENT_GC, __uuidof(CorRuntimeHost), __uuidof(ICorRuntimeHost), (LPVOID*)&m_pHost), m_pHost);

	if (FAILED(m_pHost->GetDefaultDomain(&pAppDomainPunk)))
	{
		if (!bRuntimeStarted)
		{
			bRuntimeStarted = TRUE;
			IfFailGo(m_pHost->Start());
			IfFailGoCheck(m_pHost->GetDefaultDomain(&pAppDomainPunk), pAppDomainPunk);
		}
		else
		{
			goto Error;
		}
	}
	if(!pAppDomainPunk)
		return E_FAIL;
	IfFailGoCheck(pAppDomainPunk->QueryInterface(__uuidof(mscorlib::_AppDomain), (LPVOID*)&m_pDefaultDomain), m_pDefaultDomain);
Error:
	return hr;
}