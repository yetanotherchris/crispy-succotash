VsUserControlHost

Because .NET UserControls are not ActiveX controls, a UserControl cannot be directly hosted on a tool window. This 
project is an ATL ActiveX control that can be hosted on a tool window. It then can create an instance of a UserControl
and parent that control onto the ActiveX control, making it look as if the UserControl is within a tool window frame.

To use this control, first build the project. Then add a reference to the VSUserControlHostLib COM object within the COM tab of the Add References dialog (found by right 
clicking on your Add-in Project). Then, in your Add-in, you would write code such as the following:

object objTemp;
VSUserControlHostLib.IVSUserControlHostCtl objVSUserControlHostCtl;
EnvDTE.Window objWindow = objDTE.Windows.CreateToolWindow(objMyAddin, "VSUserControlHost.VSUserControlHostCtl", "My tool window", "{some random guid}", objVSUserControlHostCtl);


Next, you would call the appropriate code to host your UserControl. The method to do this has two formats. The first looks for an assembly that is in the GAC. 
This is demonstrated with this code, which will use a standard CheckBox as the UserControl:
	objVSUserControlHostCtl.HostUserControl("System.Windows.Forms", "System.Windows.Forms.CheckBox");

The second format is to specify an absolute path to an assembly. This is best when you do not have permissions to write into the GAC or you wish to use a user control within the 
assembly that is calling the code:
	objVSUserControlHostCtl.HostUserControl("C:\path\WindowsControlLibrary1.dll", "WindowsControlLibrary1.UserControl1");
If the user control is within the same assembly that the Add-in is located, you could use code like this to discover the path:
	objVSUserControlHostCtl.HostUserControl(System.Reflection.Assembly.GetExecutingAssembly().CodeBase, "WindowsControlLibrary1.UserControl1");


The second parameter to the HostUserControl method is the full name to the class implementing the UserControl.

The second way to host a user control is to host it by it's window handle. The HostUserControl2 method accepts as an argument an HWND. The hosted HWND will be parented
onto the shim control. This is helpfull if the control you wish to host has already been created, but it is not advised to use this technique because, since the shim knows
the User Control only by it's HWND, the object the window contains cannot be returned.

You may redistribute this control with your Add-in, however you should make a few changes to the code first to make sure that your code will work
with the Add-ins of others which also use the shim. You do this by making the following changes:
	Search for, and replace these GUIDs with your own GUID:
		5BC4D5A3-F1C8-44F5-8C62-E0BF5CBE92EB
		280D96EA-474C-486E-88BE-5EB39FC4ACCB
		FE224107-D60D-4775-913F-4DED40FD84F5

	Search for, and replace these ProgIDs with your own ProgID:
		VSUserControlHost.VSUserControlHostCtl
		VSUserControlHost.VSUserControlHostCtl.1
